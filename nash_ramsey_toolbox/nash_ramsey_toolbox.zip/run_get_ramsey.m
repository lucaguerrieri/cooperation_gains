get_ramsey;
make_ss;
replace_big_lags_leads;