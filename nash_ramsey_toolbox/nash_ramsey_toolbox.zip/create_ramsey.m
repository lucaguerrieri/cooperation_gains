%% Shell 2
function[lmultlist] = create_ramsey(infilename, outfilename);

ramsey_flag = 1;

for i = 1:2
    gen_lmults(i);
end;

end;